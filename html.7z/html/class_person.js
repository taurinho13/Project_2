var class_person =
[
    [ "Person", "class_person.html#a0397c6f89fafc12e738923f612bc41a3", null ],
    [ "Person", "class_person.html#aa9413188fbd6ac7e4cb749283afcaa24", null ],
    [ "~Person", "class_person.html#a22234d7de3132c581406f040196eef44", null ],
    [ "display", "class_person.html#afc955584e777925301142538d0262e9d", null ],
    [ "pavarde", "class_person.html#a0f7720daa479637fbeddb17121f08086", null ],
    [ "vardas", "class_person.html#a10706125d01fcc75af3cb89d39465067", null ]
];
var annotated_dup =
[
    [ "Person", "class_person.html", "class_person" ],
    [ "zmogus", "classzmogus.html", "classzmogus" ]
];
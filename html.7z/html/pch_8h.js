var pch_8h =
[
    [ "Person", "class_person.html", "class_person" ],
    [ "zmogus", "classzmogus.html", "classzmogus" ],
    [ "ZMOGUS_H", "pch_8h.html#a2fff5759f39a466884cdbf46c5a74fb8", null ],
    [ "calculateAverage", "pch_8h.html#ab70dcc5fde0adc4df02814cb6429f310", null ],
    [ "calculateGalutinis", "pch_8h.html#aee4f0ab2095b3d576772f9b0998daa37", null ],
    [ "calculateGalutinisForFile", "pch_8h.html#a13933b86acdc4d64a623dfb6572057b8", null ],
    [ "calculateMedian", "pch_8h.html#ad9ba8b1a06e22b1bcdda3ac90bbb66ba", null ],
    [ "compareStudents", "pch_8h.html#a5ff875bb14eac84baadebd9cd11c4421", null ],
    [ "generateRandomGrades", "pch_8h.html#aedf7e43d28e7bf8c59cb3fb5d3dc4a71", null ],
    [ "generateStudentFile", "pch_8h.html#afc9ee4800923dfbf13dc0f5c8d8400a9", null ],
    [ "generateStudentFilesAutomatically", "pch_8h.html#ac4a2d1b1071e1dc1e1ca2a3a3947aa06", null ],
    [ "inputStudentData", "pch_8h.html#a1f27d8a2a14e27145d80016ed9572967", null ],
    [ "printStudentData", "pch_8h.html#a893c004fdad0034a235d611f98e4b348", null ],
    [ "printStudentDataToFile", "pch_8h.html#a510583c14a75d2a9855edc870c2cacbb", null ],
    [ "processFileData", "pch_8h.html#a1639ba5fd86c978c7a053da0b16125ce", null ],
    [ "processLine", "pch_8h.html#a4c0723b5d977c3dfb457e20a4b754d2e", null ],
    [ "rikiavimas", "pch_8h.html#a334a3ec952b4d25a5c780c24f199527a", null ],
    [ "rikiavimaspav", "pch_8h.html#a2db2193214e83db47c483d0f1e2924b9", null ]
];
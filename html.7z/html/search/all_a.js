var searchData=
[
  ['setegzaminas_0',['setEgzaminas',['../classzmogus.html#a1ab0b944496b0d45bf818ee6857741b3',1,'zmogus']]],
  ['setgalutinis_1',['setGalutinis',['../classzmogus.html#ae0cc3a8e1fce79c4f4868f4600251292',1,'zmogus']]],
  ['setmed_2',['setMed',['../classzmogus.html#a379a1df46cac61a477598514694340c2',1,'zmogus']]],
  ['setpavarde_3',['setPavarde',['../classzmogus.html#aaee9444213125baa18b4dc866bd1b299',1,'zmogus']]],
  ['setvardas_4',['setVardas',['../classzmogus.html#a528e2beefa298a4f8a11f93173f0d2ce',1,'zmogus']]],
  ['setvid_5',['setVid',['../classzmogus.html#a7ce5a9ae624b6421c3933be4075fa49e',1,'zmogus']]]
];

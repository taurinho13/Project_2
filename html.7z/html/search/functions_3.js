var searchData=
[
  ['generaterandomgrades_0',['generateRandomGrades',['../pch_8h.html#aedf7e43d28e7bf8c59cb3fb5d3dc4a71',1,'generateRandomGrades(zmogus &amp;zmog, int ndskaicius):&#160;phc.cpp'],['../phc_8cpp.html#aedf7e43d28e7bf8c59cb3fb5d3dc4a71',1,'generateRandomGrades(zmogus &amp;zmog, int ndskaicius):&#160;phc.cpp']]],
  ['generatestudentfile_1',['generateStudentFile',['../pch_8h.html#afc9ee4800923dfbf13dc0f5c8d8400a9',1,'generateStudentFile(int numStudents, int numHomeworks, const std::string &amp;filename):&#160;phc.cpp'],['../phc_8cpp.html#afc9ee4800923dfbf13dc0f5c8d8400a9',1,'generateStudentFile(int numStudents, int numHomeworks, const std::string &amp;filename):&#160;phc.cpp']]],
  ['generatestudentfilesautomatically_2',['generateStudentFilesAutomatically',['../pch_8h.html#ac4a2d1b1071e1dc1e1ca2a3a3947aa06',1,'generateStudentFilesAutomatically():&#160;phc.cpp'],['../phc_8cpp.html#ac4a2d1b1071e1dc1e1ca2a3a3947aa06',1,'generateStudentFilesAutomatically():&#160;phc.cpp']]],
  ['getegzaminas_3',['getEgzaminas',['../classzmogus.html#a5eb4fd6a985193109c17ad4fcf862f06',1,'zmogus']]],
  ['getgalutinis_4',['getGalutinis',['../classzmogus.html#ad0713039a5d184cf7f7458e8be199d42',1,'zmogus']]],
  ['getmed_5',['getMed',['../classzmogus.html#a000429d72c17c9b62c8335110731b167',1,'zmogus']]],
  ['getpavarde_6',['getPavarde',['../classzmogus.html#a5dfb525146fe08355f3e4aae7357c5da',1,'zmogus']]],
  ['getpaz_7',['getPaz',['../classzmogus.html#a52523037b35c8198ad988d36cd080c47',1,'zmogus']]],
  ['getvardas_8',['getVardas',['../classzmogus.html#a1c16f5d3a776dd517d3b6c3a2244d49f',1,'zmogus']]],
  ['getvid_9',['getVid',['../classzmogus.html#a1c5b7982a48156491071dd19f4443610',1,'zmogus']]]
];

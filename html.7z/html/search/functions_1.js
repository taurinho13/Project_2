var searchData=
[
  ['calculateaverage_0',['calculateAverage',['../pch_8h.html#ab70dcc5fde0adc4df02814cb6429f310',1,'calculateAverage(zmogus &amp;laikinas):&#160;phc.cpp'],['../phc_8cpp.html#a3f8af2d0ac7629a2088e67ee73970a4c',1,'calculateAverage(zmogus &amp;zmog):&#160;phc.cpp']]],
  ['calculategalutinis_1',['calculateGalutinis',['../classzmogus.html#a58e4801c8188e4e942de0efec247192a',1,'zmogus::calculateGalutinis()'],['../pch_8h.html#aee4f0ab2095b3d576772f9b0998daa37',1,'calculateGalutinis(zmogus &amp;student):&#160;phc.cpp'],['../phc_8cpp.html#aee4f0ab2095b3d576772f9b0998daa37',1,'calculateGalutinis(zmogus &amp;student):&#160;phc.cpp']]],
  ['calculategalutinisforfile_2',['calculateGalutinisForFile',['../pch_8h.html#a13933b86acdc4d64a623dfb6572057b8',1,'calculateGalutinisForFile(const std::string &amp;filename, std::string rusiavimoKriterijus, int strategija):&#160;pch.h'],['../phc_8cpp.html#a798010e7da09b2c79b04710bb4b42213',1,'calculateGalutinisForFile(const string &amp;filename, string rusiavimoKriterijus, int strategija):&#160;phc.cpp']]],
  ['calculatemedian_3',['calculateMedian',['../pch_8h.html#ad9ba8b1a06e22b1bcdda3ac90bbb66ba',1,'calculateMedian(zmogus &amp;laikinas):&#160;phc.cpp'],['../phc_8cpp.html#aa4077b9787dcadd14a73ac982bc15ea1',1,'calculateMedian(zmogus &amp;zmog):&#160;phc.cpp']]],
  ['clearnd_4',['clearND',['../classzmogus.html#a4d371e99864d7a41e0c5eb7eb8505522',1,'zmogus']]],
  ['comparestudents_5',['compareStudents',['../pch_8h.html#a5ff875bb14eac84baadebd9cd11c4421',1,'compareStudents(const zmogus &amp;a, const zmogus &amp;b):&#160;phc.cpp'],['../phc_8cpp.html#a5ff875bb14eac84baadebd9cd11c4421',1,'compareStudents(const zmogus &amp;a, const zmogus &amp;b):&#160;phc.cpp']]]
];

var searchData=
[
  ['vardas_0',['vardas',['../class_person.html#a10706125d01fcc75af3cb89d39465067',1,'Person']]]
];

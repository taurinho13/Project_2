var searchData=
[
  ['readzmogus_0',['readzmogus',['../classzmogus.html#a8074ec5a2ef43aa010281f5f8e57b09c',1,'zmogus']]],
  ['rikiavimas_1',['rikiavimas',['../pch_8h.html#a334a3ec952b4d25a5c780c24f199527a',1,'rikiavimas(const zmogus &amp;a, const zmogus &amp;b):&#160;phc.cpp'],['../phc_8cpp.html#a334a3ec952b4d25a5c780c24f199527a',1,'rikiavimas(const zmogus &amp;a, const zmogus &amp;b):&#160;phc.cpp']]],
  ['rikiavimaspav_2',['rikiavimaspav',['../pch_8h.html#a2db2193214e83db47c483d0f1e2924b9',1,'rikiavimaspav(const zmogus &amp;a, const zmogus &amp;b):&#160;phc.cpp'],['../phc_8cpp.html#a2db2193214e83db47c483d0f1e2924b9',1,'rikiavimaspav(const zmogus &amp;a, const zmogus &amp;b):&#160;phc.cpp']]]
];

var searchData=
[
  ['addpazymys_0',['addPazymys',['../classzmogus.html#aca1ee1ce0bfceca631d45d95c5a43dbe',1,'zmogus']]]
];

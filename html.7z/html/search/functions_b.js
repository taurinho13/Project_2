var searchData=
[
  ['_7eperson_0',['~Person',['../class_person.html#a22234d7de3132c581406f040196eef44',1,'Person']]],
  ['_7ezmogus_1',['~zmogus',['../classzmogus.html#a03d8b774303f436c2d94a8341b0dce3a',1,'zmogus']]]
];

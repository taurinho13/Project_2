var indexSectionsWithContent =
{
  0: "acdgilmoprsvz~",
  1: "pz",
  2: "lp",
  3: "acdgimoprsz~",
  4: "pv",
  5: "o",
  6: "z"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "related",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Friends",
  6: "Macros"
};


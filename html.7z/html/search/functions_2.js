var searchData=
[
  ['display_0',['display',['../class_person.html#afc955584e777925301142538d0262e9d',1,'Person::display()'],['../classzmogus.html#a20a854019f65d2873102a262dd524c2b',1,'zmogus::display()']]]
];

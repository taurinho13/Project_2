var searchData=
[
  ['inputstudentdata_0',['inputStudentData',['../pch_8h.html#a1f27d8a2a14e27145d80016ed9572967',1,'inputStudentData(std::list&lt; zmogus &gt; &amp;grupe):&#160;pch.h'],['../phc_8cpp.html#afeb452306fb996b4551b10d492fbec26',1,'inputStudentData(list&lt; zmogus &gt; &amp;grupe):&#160;phc.cpp']]]
];

var files_dup =
[
    [ "listcl.cpp", "listcl_8cpp.html", "listcl_8cpp" ],
    [ "pch.h", "pch_8h.html", "pch_8h" ],
    [ "phc.cpp", "phc_8cpp.html", "phc_8cpp" ]
];
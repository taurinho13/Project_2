var hierarchy =
[
    [ "Person", "class_person.html", [
      [ "zmogus", "classzmogus.html", null ]
    ] ]
];